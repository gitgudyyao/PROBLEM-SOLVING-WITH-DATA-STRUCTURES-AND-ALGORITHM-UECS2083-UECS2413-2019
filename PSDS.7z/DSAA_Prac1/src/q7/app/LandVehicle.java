package q7.app;

public abstract class LandVehicle extends Vehicle implements VehicleMethods {
	
}
