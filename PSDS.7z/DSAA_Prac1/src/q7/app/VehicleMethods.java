package q7.app;

public interface VehicleMethods {
	public double getWeight();
	public int getSpeed();
}
