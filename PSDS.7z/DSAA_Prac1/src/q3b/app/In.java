package q3b.app;

class Base {
	public void Base() {
		System.out.println("Base");
	}
}

public class In extends Base {
	public static void main(String argv[]) {
		In i = new In();
	}
}