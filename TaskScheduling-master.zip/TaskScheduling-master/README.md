# TaskScheduling

Feed a list of jobs into the program, each job contains its profit upon completion, duration to complete the job and the job id.
 Only one job can be executed at once and once the job has started, it has to be completed before the next job execution. 

Then, to use the function, you will need to give the time frame to do the jobs as well. When the program executes, it will schedule the jobs in such a way that the maximum profit is gained within the time frame. 
# Example
To understand the problem better, let's look at this example. 
Let's say we have 4 jobs.<br>
j1 {duration: 3, profit: 4} <br>
j2 {duration: 2, profit: 13} <br>
j3 {duration: 5, profit: 40} <br>
j4 {duration: 1, profit: 9} <br><br>
If the time frame given is 6.
Then the output of the program will be <br>
j3 j4 
<br><br>
If the time frame given is 1.
Then the output of the program will be <br>
j4 
<br><br>
If the time frame given is 11.
Then the output of the program will be <br>
j3 j2 j4 j1
<br>
# Used algorithm
The algorithm being used is greedy algorithm. 
First, it will sort the jobs based on the profit per duration in a decreasing manner. 
Then, using the sorted jobs, it will check it one by one from the start of the jobs whether it can fits into the 
remaining time frame or not.
# Important Notes on importing the project
If you try to download the zip file of this project and try to import it with archive in Eclipse, please make sure you tick the correct item (where it show it can be imported as Eclipse project) as shown in the picture below.
![alt text](https://user-images.githubusercontent.com/15872787/62290049-ed3e0380-b492-11e9-9d4a-14e1b4ded540.png)
