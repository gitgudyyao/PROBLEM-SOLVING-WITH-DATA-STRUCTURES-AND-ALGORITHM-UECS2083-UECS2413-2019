public class Task{
	private int duration;
	private int profit;
	private String id;
	
	public String getId() {
		return id;
	}
	
	public int getDuration() {
		return duration;
	}
	
	public int getProfit() {
		return profit;
	}
	
	public Task(int duration, int profit, String id) {
		this.duration = duration;
		this.profit = profit;
		this.id = id;
	}
	
}
