import java.util.*;

public class Driver {

	public static void main(String[] args) {
		LinkedList<Task> tasks = new LinkedList<Task>();
		System.out.println("Task scheduler\nEverything is randomize\n\nList of randomize jobs:");
		
		Random rand = new Random();
		int time = rand.nextInt(20) + 1;
		for(int i=0;i<5;i++) {
			int duration = rand.nextInt(10) + 1;
			int profit = rand.nextInt(10) + 1;
			String jobId = "j" + (i+1);
			
			Task t = new Task(duration,profit,jobId);
			tasks.add(t);
			System.out.println(jobId + ":{duration: " + duration + ", " + "profit: " + profit + "}");
		}
		System.out.println("\nRandomize time frame: " + time);
		
		/*
		Task t1 = new Task(5,7,"j1");
		Task t2 = new Task(10,5,"j2");
		Task t3 = new Task(3,1,"j3");
		Task t4 = new Task(8,5,"j4");
		Task t5 = new Task(2,7,"j5");
		tasks.add(t1);
		tasks.add(t2);
		tasks.add(t3);
		tasks.add(t4);
		tasks.add(t5);
		*/
		Scheduler scheduler = new Scheduler();
		
		scheduler.printTaskSchedule(tasks, time);
	}
}
