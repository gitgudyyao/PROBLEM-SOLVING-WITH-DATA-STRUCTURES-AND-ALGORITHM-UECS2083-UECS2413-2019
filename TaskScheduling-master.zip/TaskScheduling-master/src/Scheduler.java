import java.util.*;

public class Scheduler {
	
	public void printTaskSchedule(LinkedList<Task> tasks, int totalTime) {
		int i,t;
		int J[][] = new int[tasks.size() + 1][totalTime + 1];
		
		for (i = 0; i <= tasks.size(); i++) { 
		    for (t = 0; t <= totalTime; t++) { 
		        if (i == 0 || t == 0) 
		            J[i][t] = 0; 
		        else if (tasks.get(i - 1).getDuration() <= t) 
		            J[i][t] = Math.max(tasks.get(i - 1).getProfit() + 
		                    J[i - 1][t - tasks.get(i - 1).getDuration()], J[i - 1][t]); 
		        else
		            J[i][t] = J[i - 1][t]; 
		    } 
		}
		
		int res = J[tasks.size()][totalTime];
		System.out.println("Total profit: " + res);
		System.out.print("Jobs: ");
		
		t = totalTime; 
		for (i = tasks.size(); i > 0 && res > 0; i--) { 
		    if (res != J[i-1][t]) {
		    	System.out.print(tasks.get(i - 1).getId() + " ");
		    	
		    	res -= tasks.get(i - 1).getProfit();
		    	t = t - tasks.get(i - 1).getDuration(); 
		    }
		}
		
	}
}
